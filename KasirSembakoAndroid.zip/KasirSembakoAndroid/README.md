# Kasir Sembako Android

Versi 1.1 dari project Kasir Sembako dengan tambahan printer Bluetooth ESC/POS dan cetak struk.

## Fitur tambahan
- Pengaturan Printer Bluetooth.
- Menampilkan printer Bluetooth yang sudah dipairing di Android.
- Memilih dan menyimpan printer berdasarkan MAC address.
- Tombol Tes Cetak.
- Kompatibel dengan printer thermal Bluetooth ESC/POS 58mm dan 80mm.
- Tombol Cetak Struk setelah transaksi.
- Riwayat Transaksi dan Cetak Ulang.
- Pengaturan nama toko, alamat, telepon, pesan bawah struk, dan ukuran kertas.
- Izin Bluetooth Android 12+ (`BLUETOOTH_CONNECT` dan `BLUETOOTH_SCAN`) dengan izin lama untuk Android <= 11.
- Database dinaikkan dari versi 1 ke versi 2 tanpa menghapus data produk/sales yang sudah ada.
- Workflow GitHub Actions untuk build APK debug.

## Cara menggunakan printer
1. Pairing printer thermal Bluetooth melalui Settings Bluetooth Android terlebih dahulu.
2. Di aplikasi tekan menu `⋮` di kanan atas.
3. Pilih `Pengaturan Printer`.
4. Pilih printer yang sudah paired lalu tekan `Simpan`.
5. Gunakan `Tes Cetak` untuk mencoba.
6. Setelah transaksi, tekan `Cetak Struk`.

Printer harus menggunakan Bluetooth Classic/SPP dan menerima perintah ESC/POS. Project tidak melakukan scan printer baru; daftar diambil dari perangkat yang sudah dipairing, sehingga pengguna dapat melakukan pairing dari pengaturan Bluetooth Android.

## Build GitHub Actions
Workflow berada di `.github/workflows/android-build.yml`.
Workflow menggunakan JDK 17, Gradle 8.9, dan menghasilkan:
`app/build/outputs/apk/debug/app-debug.apk`

## Catatan
Build final perlu dijalankan di GitHub Actions/komputer yang memiliki Android SDK dan akses dependency Gradle. Lingkungan pembuatan file ini tidak memiliki akses jaringan untuk mengunduh Gradle/SDK, jadi APK tidak diklaim sudah diuji build lokal di sini.
