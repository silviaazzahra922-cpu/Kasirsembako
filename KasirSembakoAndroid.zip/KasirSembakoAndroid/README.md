# Kasir Sembako Android + Printer Bluetooth

Project POS sembako Android dengan tampilan kasir compact.

## Fitur
- Produk, stok, transaksi, dan laporan.
- Printer Bluetooth ESC/POS untuk thermal 58mm dan 80mm.
- Pengaturan Printer: daftar printer Bluetooth yang sudah dipairing, pilih/simpan printer, Tes Cetak.
- Cetak struk setelah transaksi.
- Riwayat transaksi, buka detail transaksi, dan Cetak Ulang.
- Pengaturan toko: nama, alamat, telepon, pesan bawah struk, ukuran kertas.
- Permission Bluetooth Android 12+ menggunakan BLUETOOTH_CONNECT/SCAN dan permission lama untuk Android <= 11.
- Data transaksi disimpan di SQLite lokal.

## Build GitHub Actions
1. Upload seluruh folder project ini ke repository GitHub.
2. Buka tab **Actions**.
3. Pilih workflow **Android Build**.
4. Tekan **Run workflow**.
5. Setelah selesai, ambil APK dari **Artifacts > KasirSembako-debug**.

Workflow menggunakan JDK 17 dan Gradle 8.9. Tidak perlu mengedit file YAML secara manual.

## Penggunaan Printer
1. Pair printer thermal Bluetooth terlebih dahulu melalui Pengaturan Bluetooth Android.
2. Buka **Menu (⋮) > Pengaturan Printer**.
3. Pilih printer yang sudah paired lalu tekan **Simpan**.
4. Tekan **Tes Cetak** untuk menguji printer.
5. Atur ukuran kertas melalui **Menu (⋮) > Pengaturan Toko**.
