package com.kasirsembako.app;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.*;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db;
    LinearLayout root, content;
    NumberFormat rupiah = NumberFormat.getCurrencyInstance(new Locale("id","ID"));
    final String PREF="settings";
    final int REQ_BT=700;
    BluetoothDevice selectedPrinter;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        db=new DB(this);
        rupiah.setMaximumFractionDigits(0);
        if (Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},REQ_BT);
        showKasir();
    }

    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.DKGRAY);t.setPadding(dp(8),dp(3),dp(8),dp(3));return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setMinHeight(0);b.setMinWidth(0);b.setPadding(dp(6),0,dp(6),0);return b;}

    void base(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(246,247,248));
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        TextView h=tv(title,15); h.setTextColor(Color.WHITE); h.setGravity(Gravity.CENTER_VERTICAL); h.setBackgroundColor(Color.rgb(46,125,50));
        head.addView(h,new LinearLayout.LayoutParams(0,dp(40),1));
        Button menu=btn("⋮"); menu.setTextColor(Color.WHITE); menu.setBackgroundColor(Color.rgb(46,125,50));
        menu.setOnClickListener(v->showMenu());
        head.addView(menu,new LinearLayout.LayoutParams(dp(48),dp(40)));
        root.addView(head);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);
        String[] ns={"Kasir","Produk","Laporan"};
        for(String n:ns){Button x=btn(n);x.setOnClickListener(v->{if(n.equals("Kasir"))showKasir();else if(n.equals("Produk"))showProduk();else showLaporan();});nav.addView(x,new LinearLayout.LayoutParams(0,dp(38),1));}
        root.addView(nav);setContentView(root);
    }

    void showMenu(){
        final String[] items={"Riwayat Transaksi","Pengaturan Toko","Pengaturan Printer"};
        new AlertDialog.Builder(this).setTitle("Menu").setItems(items,(d,w)->{
            if(w==0)showHistory(); else if(w==1)showStoreSettings(); else showPrinterSettings();
        }).show();
    }

    void showKasir(){
        base("Kasir Sembako");
        ArrayList<String> names=new ArrayList<>();
        Cursor c=db.products();
        while(c.moveToNext())names.add(c.getInt(0)+" | "+c.getString(1)+" | "+rupiah.format(c.getLong(3))+" | stok "+c.getInt(4));
        c.close();
        if(names.size()==0){content.addView(tv("Belum ada produk. Tambahkan di menu Produk.",14));return;}
        Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));content.addView(sp,new LinearLayout.LayoutParams(-1,dp(38)));
        EditText qty=new EditText(this);qty.setHint("Jumlah");qty.setTextSize(15);qty.setSingleLine(true);qty.setInputType(2);qty.setPadding(dp(8),0,dp(8),0);content.addView(qty,new LinearLayout.LayoutParams(-1,dp(38)));
        Button b=btn("TAMBAH KE TRANSAKSI");content.addView(b,new LinearLayout.LayoutParams(-1,dp(38)));
        TextView cart=tv("Transaksi baru",13);content.addView(cart);
        b.setOnClickListener(v->{
            try{
                String[] p=sp.getSelectedItem().toString().split(" \\| ");
                int id=Integer.parseInt(p[0]);int q=Integer.parseInt(qty.getText().toString().isEmpty()?"1":qty.getText().toString());
                if(q<=0)throw new Exception();
                Cursor pc=db.one(id);
                if(pc.moveToFirst()){
                    int stock=pc.getInt(4);long price=pc.getLong(3);
                    if(q>stock)Toast.makeText(this,"Stok tidak cukup",Toast.LENGTH_SHORT).show();
                    else{
                        long total=price*q; cart.setText("Transaksi baru\n"+pc.getString(1)+" x"+q+" = "+rupiah.format(total));
                        Button pay=btn("BAYAR & SIMPAN");content.addView(pay,new LinearLayout.LayoutParams(-1,dp(38)));
                        pay.setOnClickListener(w->paymentDialog(id,q,total,pc.getString(1),price));
                    }
                }
                pc.close();
            }catch(Exception ex){Toast.makeText(this,"Jumlah tidak valid",Toast.LENGTH_SHORT).show();}
        });
    }

    void paymentDialog(int productId,int q,long total,String product,long price){
        LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(12),dp(4),dp(12),0);
        TextView info=tv(product+" x"+q+"\nTotal: "+rupiah.format(total),15);f.addView(info);
        EditText paid=new EditText(this);paid.setHint("Uang bayar");paid.setInputType(InputType.TYPE_CLASS_NUMBER);paid.setSingleLine(true);f.addView(paid);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Pembayaran").setView(f)
            .setNegativeButton("Batal",null).setPositiveButton("Simpan",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            long uang=num(paid);
            if(uang<total){paid.setError("Uang bayar kurang");return;}
            long change=uang-total;
            long tx=db.sale(productId,q,total,uang,change);
            dlg.dismiss();
            showReceiptActions(tx);
        }));
        dlg.show();
    }

    void showReceiptActions(long txId){
        new AlertDialog.Builder(this).setTitle("Transaksi tersimpan")
            .setMessage("Nomor transaksi: "+db.txNumber(txId)+"\nTotal: "+rupiah.format(db.txTotal(txId)))
            .setNegativeButton("Tutup",(d,w)->showKasir())
            .setPositiveButton("Cetak Struk",(d,w)->printTransaction(txId))
            .show();
    }

    void showProduk(){
        base("Data Produk");Button add=btn("+ TAMBAH PRODUK");content.addView(add,new LinearLayout.LayoutParams(-1,dp(42)));add.setOnClickListener(v->dialogProduk(-1));
        Cursor c=db.products();while(c.moveToNext()){final int id=c.getInt(0);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
            TextView x=tv(c.getString(1)+"\nBeli: "+rupiah.format(c.getLong(2))+" | Jual: "+rupiah.format(c.getLong(3))+" | Stok: "+c.getInt(4),15);row.addView(x,new LinearLayout.LayoutParams(0,dp(50),1));
            Button e=btn("Edit");row.addView(e);e.setOnClickListener(v->dialogProduk(id));content.addView(row);}
        c.close();
    }
    void dialogProduk(int id){
        LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);
        EditText n=new EditText(this);n.setHint("Nama produk");EditText beli=new EditText(this);beli.setHint("Harga beli");beli.setInputType(2);
        EditText jual=new EditText(this);jual.setHint("Harga jual");jual.setInputType(2);EditText stok=new EditText(this);stok.setHint("Stok");stok.setInputType(2);
        f.addView(n);f.addView(beli);f.addView(jual);f.addView(stok);
        if(id>0){Cursor c=db.one(id);if(c.moveToFirst()){n.setText(c.getString(1));beli.setText(""+c.getLong(2));jual.setText(""+c.getLong(3));stok.setText(""+c.getInt(4));}c.close();}
        new AlertDialog.Builder(this).setTitle(id<0?"Tambah Produk":"Edit Produk").setView(f).setPositiveButton("Simpan",(d,w)->{db.save(id,n.getText().toString(),num(beli),num(jual),(int)num(stok));showProduk();}).setNegativeButton("Batal",null).show();
    }
    long num(EditText e){try{return Long.parseLong(e.getText().toString());}catch(Exception x){return 0;}}

    void showLaporan(){
        base("Laporan");Cursor c=db.report();long omzet=0,profit=0;int trx=0;
        while(c.moveToNext()){trx+=c.getInt(0);omzet+=c.getLong(1);profit+=c.getLong(2);}c.close();
        content.addView(tv("Ringkasan\nTransaksi: "+trx+"\nOmzet: "+rupiah.format(omzet)+"\nPerkiraan laba: "+rupiah.format(profit),16));
    }

    void showHistory(){
        base("Riwayat Transaksi");
        Cursor c=db.transactions();
        if(!c.moveToFirst()){content.addView(tv("Belum ada transaksi.",14));c.close();return;}
        do{
            final long id=c.getLong(0); String no=c.getString(1); long total=c.getLong(2); long paid=c.getLong(3);long change=c.getLong(4);long created=c.getLong(5);
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
            TextView x=tv(no+"\n"+fmtDate(created)+"\nTotal: "+rupiah.format(total),14);row.addView(x,new LinearLayout.LayoutParams(0,dp(65),1));
            Button pr=btn("Cetak\nUlang");row.addView(pr,new LinearLayout.LayoutParams(dp(85),dp(65)));
            pr.setOnClickListener(v->printTransaction(id));content.addView(row);
        }while(c.moveToNext());c.close();
    }

    void showStoreSettings(){
        LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(12),0,dp(12),0);
        EditText name=field("Nama toko",getPref("store_name","Toko Sembako"));
        EditText addr=field("Alamat toko",getPref("store_addr",""));
        EditText phone=field("Nomor HP/telepon",getPref("store_phone",""));
        EditText footer=field("Pesan bawah struk",getPref("store_footer","Terima kasih sudah berbelanja"));
        Spinner paper=new Spinner(this);paper.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"58mm","80mm"}));
        paper.setSelection(getPref("paper","58mm").equals("80mm")?1:0);
        f.addView(name);f.addView(addr);f.addView(phone);f.addView(footer);f.addView(paper);
        new AlertDialog.Builder(this).setTitle("Pengaturan Toko").setView(f).setPositiveButton("Simpan",(d,w)->{
            getPreferences(MODE_PRIVATE).edit().putString("store_name",name.getText().toString()).putString("store_addr",addr.getText().toString()).putString("store_phone",phone.getText().toString()).putString("store_footer",footer.getText().toString()).putString("paper",paper.getSelectedItem().toString()).apply();
            Toast.makeText(this,"Pengaturan disimpan",Toast.LENGTH_SHORT).show();
        }).setNegativeButton("Batal",null).show();
    }
    EditText field(String hint,String value){EditText e=new EditText(this);e.setHint(hint);e.setText(value);e.setSingleLine(false);return e;}
    String getPref(String k,String d){return getPreferences(MODE_PRIVATE).getString(k,d);}

    void showPrinterSettings(){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);return;
        }
        BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();
        if(adapter==null){Toast.makeText(this,"Perangkat tidak mendukung Bluetooth",Toast.LENGTH_LONG).show();return;}
        if(!adapter.isEnabled()){Toast.makeText(this,"Aktifkan Bluetooth lalu buka pengaturan printer lagi",Toast.LENGTH_LONG).show();startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));return;}
        ArrayList<BluetoothDevice> devices=new ArrayList<>();
        ArrayList<String> labels=new ArrayList<>();
        try{
            for(BluetoothDevice d:adapter.getBondedDevices()){devices.add(d);labels.add(d.getName()+"\n"+d.getAddress());}
        }catch(SecurityException e){Toast.makeText(this,"Izin Bluetooth belum diberikan",Toast.LENGTH_SHORT).show();return;}
        if(devices.isEmpty()){new AlertDialog.Builder(this).setTitle("Pengaturan Printer").setMessage("Belum ada printer Bluetooth yang dipairing. Pairing printer melalui Pengaturan Bluetooth Android terlebih dahulu.").setPositiveButton("OK",null).show();return;}
        String saved=getPref("printer_mac","");
        int checked=-1;for(int i=0;i<devices.size();i++)if(devices.get(i).getAddress().equals(saved))checked=i;
        final int[] pick={checked<0?0:checked};
        new AlertDialog.Builder(this).setTitle("Printer Bluetooth")
            .setSingleChoiceItems(labels.toArray(new String[0]),pick[0],(d,w)->pick[0]=w)
            .setNeutralButton("Tes Cetak",null).setPositiveButton("Simpan",null).setNegativeButton("Batal",null)
            .create();
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Printer Bluetooth")
            .setSingleChoiceItems(labels.toArray(new String[0]),pick[0],(d,w)->pick[0]=w)
            .setNeutralButton("Tes Cetak",(d,w)->testPrint(devices.get(pick[0])))
            .setPositiveButton("Simpan",(d,w)->{
                getPreferences(MODE_PRIVATE).edit().putString("printer_mac",devices.get(pick[0]).getAddress()).apply();
                Toast.makeText(this,"Printer tersimpan: "+devices.get(pick[0]).getName(),Toast.LENGTH_SHORT).show();
            }).setNegativeButton("Batal",null).create();
        dlg.show();
    }

    void testPrint(BluetoothDevice d){
        new Thread(()->{
            try{
                byte[] data=escInit();
                data=concat(data,escText("TES CETAK\n"+getPref("store_name","Toko Sembako")+"\nPrinter: "+d.getName()+"\n\n"));
                data=concat(data,new byte[]{0x1d,0x56,0x41,0x03});
                send(d,data);
                runOnUiThread(()->Toast.makeText(this,"Tes cetak berhasil dikirim",Toast.LENGTH_SHORT).show());
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Gagal mencetak: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }).start();
    }

    void printTransaction(long txId){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);return;}
        String mac=getPref("printer_mac","");
        if(mac.isEmpty()){Toast.makeText(this,"Pilih printer di Pengaturan Printer terlebih dahulu",Toast.LENGTH_LONG).show();showPrinterSettings();return;}
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();
        try{
            BluetoothDevice d=a.getRemoteDevice(mac);
            new Thread(()->{
                try{send(d,receiptBytes(txId));runOnUiThread(()->Toast.makeText(this,"Struk terkirim ke printer",Toast.LENGTH_SHORT).show());}
                catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Gagal mencetak: "+e.getMessage(),Toast.LENGTH_LONG).show());}
            }).start();
        }catch(Exception e){Toast.makeText(this,"Printer tidak ditemukan",Toast.LENGTH_LONG).show();}
    }

    byte[] receiptBytes(long txId){
        int width=getPref("paper","58mm").equals("80mm")?48:32;
        StringBuilder s=new StringBuilder();
        s.append(getPref("store_name","Toko Sembako")).append("\n");
        s.append(getPref("store_addr","")).append("\n");
        s.append(getPref("store_phone","")).append("\n");
        s.append(repeat("-",width)).append("\n");
        s.append("No: ").append(db.txNumber(txId)).append("\n");
        s.append(fmtDate(db.txCreated(txId))).append("\n");
        s.append(repeat("-",width)).append("\n");
        Cursor c=db.items(txId);
        while(c.moveToNext()){
            String n=c.getString(0);int q=c.getInt(1);long price=c.getLong(2);long sub=c.getLong(3);
            s.append(n).append("\n");
            s.append(q).append(" x ").append(money(price)).append(" = ").append(money(sub)).append("\n");
        }
        c.close();
        s.append(repeat("-",width)).append("\n");
        s.append("TOTAL       ").append(money(db.txTotal(txId))).append("\n");
        s.append("UANG BAYAR  ").append(money(db.txPaid(txId))).append("\n");
        s.append("KEMBALIAN   ").append(money(db.txChange(txId))).append("\n");
        s.append(repeat("-",width)).append("\n");
        s.append(getPref("store_footer","Terima kasih sudah berbelanja")).append("\n\n\n");
        return concat(escInit(),escText(s.toString()),new byte[]{0x1d,0x56,0x41,0x03});
    }
    String money(long n){return rupiah.format(n).replace("Rp","Rp ");}
    String repeat(String x,int n){StringBuilder b=new StringBuilder();for(int i=0;i<n;i++)b.append(x);return b.toString();}
    String fmtDate(long t){return new SimpleDateFormat("dd-MM-yyyy HH:mm:ss",Locale.getDefault()).format(new Date(t));}
    byte[] escInit(){return new byte[]{0x1b,0x40,0x1b,0x61,0x01};}
    byte[] escText(String s){return s.getBytes(Charset.forName("CP437"));}
    byte[] concat(byte[] a,byte[] b){byte[] r=new byte[a.length+b.length];System.arraycopy(a,0,r,0,a.length);System.arraycopy(b,0,r,a.length,b.length);return r;}
    void send(BluetoothDevice d,byte[] data)throws Exception{
        BluetoothSocket socket=d.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
        socket.connect();OutputStream os=socket.getOutputStream();os.write(data);os.flush();Thread.sleep(250);os.close();socket.close();
    }

    static class DB extends SQLiteOpenHelper{
        DB(Context c){super(c,"kasir.db",null,2);}
        public void onCreate(SQLiteDatabase d){
            d.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,buy INTEGER,sell INTEGER,stock INTEGER)");
            d.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER,qty INTEGER,total INTEGER,profit INTEGER,created INTEGER)");
            d.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,number TEXT,total INTEGER,paid INTEGER,change_amt INTEGER,created INTEGER)");
            d.execSQL("CREATE TABLE sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,transaction_id INTEGER,product_id INTEGER,qty INTEGER,price INTEGER,subtotal INTEGER)");
            d.execSQL("INSERT INTO products(name,buy,sell,stock) VALUES('Beras 5 Kg',60000,72000,10),('Minyak 1 L',15000,18000,20),('Gula 1 Kg',16000,19000,15)");
        }
        public void onUpgrade(SQLiteDatabase d,int o,int n){
            if(o<2){
                d.execSQL("CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY AUTOINCREMENT,number TEXT,total INTEGER,paid INTEGER,change_amt INTEGER,created INTEGER)");
                d.execSQL("CREATE TABLE IF NOT EXISTS sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,transaction_id INTEGER,product_id INTEGER,qty INTEGER,price INTEGER,subtotal INTEGER)");
            }
        }
        Cursor products(){return getReadableDatabase().rawQuery("SELECT * FROM products ORDER BY name",null);}
        Cursor one(int id){return getReadableDatabase().rawQuery("SELECT * FROM products WHERE id=?",new String[]{""+id});}
        void save(int id,String n,long b,long s,int st){SQLiteDatabase d=getWritableDatabase();if(id<0)d.execSQL("INSERT INTO products(name,buy,sell,stock) VALUES(?,?,?,?)",new Object[]{n,b,s,st});else d.execSQL("UPDATE products SET name=?,buy=?,sell=?,stock=? WHERE id=?",new Object[]{n,b,s,st,id});}
        long sale(int id,int q,long total,long paid,long change){
            SQLiteDatabase d=getWritableDatabase();d.beginTransaction();
            long txId=0;Cursor c=null;
            try{
                c=one(id);c.moveToFirst();long profit=(c.getLong(3)-c.getLong(2))*q;long now=System.currentTimeMillis();
                String no=new SimpleDateFormat("yyyyMMdd-HHmmss",Locale.getDefault()).format(new Date(now));
                d.execSQL("INSERT INTO transactions(number,total,paid,change_amt,created) VALUES(?,?,?,?,?)",new Object[]{no,total,paid,change,now});
                txId=DatabaseUtils.longForQuery(d,"SELECT last_insert_rowid()",null);
                d.execSQL("INSERT INTO sale_items(transaction_id,product_id,qty,price,subtotal) VALUES(?,?,?,?,?)",new Object[]{txId,id,q,c.getLong(3),total});
                d.execSQL("INSERT INTO sales(product_id,qty,total,profit,created) VALUES(?,?,?,?,?)",new Object[]{id,q,total,profit,now});
                d.execSQL("UPDATE products SET stock=stock-? WHERE id=?",new Object[]{q,id});
                d.setTransactionSuccessful();
            }finally{if(c!=null)c.close();d.endTransaction();}
            return txId;
        }
        Cursor report(){return getReadableDatabase().rawQuery("SELECT COUNT(*),COALESCE(SUM(total),0),COALESCE(SUM(profit),0) FROM sales",null);}
        Cursor transactions(){return getReadableDatabase().rawQuery("SELECT id,number,total,paid,change_amt,created FROM transactions ORDER BY id DESC",null);}
        Cursor items(long tx){return getReadableDatabase().rawQuery("SELECT p.name,i.qty,i.price,i.subtotal FROM sale_items i JOIN products p ON p.id=i.product_id WHERE i.transaction_id=?",new String[]{""+tx});}
        String txNumber(long id){return oneVal("number",id);}
        long txTotal(long id){return longVal("total",id);}
        long txPaid(long id){return longVal("paid",id);}
        long txChange(long id){return longVal("change_amt",id);}
        long txCreated(long id){return longVal("created",id);}
        String oneVal(String col,long id){Cursor c=getReadableDatabase().rawQuery("SELECT "+col+" FROM transactions WHERE id=?",new String[]{""+id});try{return c.moveToFirst()?c.getString(0):"";}finally{c.close();}}
        long longVal(String col,long id){Cursor c=getReadableDatabase().rawQuery("SELECT "+col+" FROM transactions WHERE id=?",new String[]{""+id});try{return c.moveToFirst()?c.getLong(0):0;}finally{c.close();}}
    }
}
